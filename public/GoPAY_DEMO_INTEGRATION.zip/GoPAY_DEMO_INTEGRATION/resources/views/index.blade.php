<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GoPAY DEMO INTEGRATION</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/font-awesome-5/css/fontawesome-all.min.css') }}">
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">{{ config('app.name') }}</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <div class="mt-5  p-3 bg-light">
                    <form id="fpay">
                        <div class="">
                            <h5 class="text-center">Payment</h5>
                            <hr>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Phone number</label>
                                <input type="tel" class="form-control" name="telephone" required
                                    placeholder="Ex : 099..." pattern="\d*" maxlength="10">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Amount</label>
                                <input type="number" step="0.01" name="amount" required class="form-control"
                                    placeholder="Ex : 500" value="500">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Currency</label>
                                <select name="devise" id="" required class="form-control">
                                    <option value="CDF">CDF</option>
                                    <option value="USD">USD</option>
                                </select>
                            </div>
                            <div id="rep"></div>
                            <button type="submit" class="btn w-100 btn-dark">
                                <i class="fas fa-check-circle"></i>
                                Pay
                            </button>
                            <button type="button" class="btn w-100 mt-2 btn-secondary ml-2" id="btncancel"
                                style="display: none">Annuler
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table tdata class="table">
                        <thead class="table-dark">
                            <tr>
                                <th></th>
                                <th>REF</th>
                                <th>AMOUNT</th>
                                <th>PHONE</th>
                                <th>DATE</th>
                                <th>PAYDATA</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('js/bootstrap.js') }}"></script>
    <script src="{{ asset('js/jquery.js') }}"></script>

    <script>
        $(function() {
            var xhr = [];
            var interv = null;
            REF = '';

            var callback = function() {
                var x =
                    $.ajax({
                        url: '{{ route('check_payment') }}',
                        data: {
                            ref: REF
                        },
                        success: function(res) {
                            var trans = res.transaction;
                            var status = trans?.status;
                            // 'success|failed|pending'
                            if (status === 'success') {
                                // PAYMENT WAS SUCCESS !!
                                clearInterval(interv);
                                $(xhr).each(function(i, e) {
                                    e.abort();
                                });
                                var form = $('#f-log');
                                var btn = $(':submit', form).attr('disabled', false);
                                btn.html(
                                    '<i class="fa fa-check-circle"></i> Pay'
                                );
                                btn.removeClass('btn-danger').addClass('btn-dark');
                                rep = $('#rep', form);
                                rep.html(res.message).removeClass();
                                rep.addClass('alert alert-success');
                                rep.slideDown();

                                var fp = $('#fpay');
                                fp.html(`<div class="d-flex mt-5 mb-5  justify-content-center align-items-center">
                                        <p class="text-success">
                                            <b><i class="fa fa-check-circle"></i> VOTRE PAIEMENT A &Eacute;T&Eacute;
                                                &Eacute;FFECTU&Eacute; !</b>
                                        </p>
                                    </div>`);
                                gettrans();
                                setTimeout(() => {
                                    // YOU CAN REDIRECT THE USER TO HIS DASHBOARD AFTER PAYEMENT COMPLETED
                                    // location.assign('https://USER_DASHBOARD_URL')
                                }, 3000);

                            } else if (status === 'failed') {
                                clearInterval(interv);
                                $('#btncancel').hide();
                                $('#btnclose').show();
                                var form = $('#fpay');
                                var btn = $(':submit', form).attr('disabled', false);
                                btn.html(
                                    '<i class="fa fa-money-bill-transfer"></i> Initier la transaction'
                                );
                                btn.removeClass('btn-danger').addClass('btn-dark');
                                var rep = $('#rep', form);
                                var html = `<div class="d-flex mt-5 mb-5  justify-content-center align-items-center">
                                        <p class="text-danger">
                                            <b><i class="fa fa-times-circle"></i> VOTRE PAIEMENT A &Eacute;CHOU&Eacute;</b>
                                        </p>
                                    </div>`;
                                rep.html(html).removeClass();
                                rep.addClass('alert alert-danger');
                                $(xhr).each(function(i, e) {
                                    e.abort();
                                });


                            }
                        }
                    });
                xhr.push(x);
            }

            $('#btncancel').click(function() {
                clearInterval(interv);
                $(this).hide();
                var form = $('#fpay');
                var btn = $(':submit', form).attr('disabled', false);
                btn.html(
                    '<i class="fa fa-check-circle"></i> Pay'
                );
                btn.removeClass('btn-dark').addClass('btn-dark');
                var rep = $('#rep', form);
                rep.html("Paiement annulé.").removeClass();
                rep.addClass('alert alert-warning');
                $(xhr).each(function(i, e) {
                    e.abort();
                });
            });

            $('#fpay').submit(function() {
                event.preventDefault();
                var form = $(this);
                var btn = $(':submit', form).attr('disabled', true);
                var iclass = btn.find('i').attr('class');
                btn.find('i').removeClass()
                    .addClass('fa fa-spinner fa-spin');
                var data = form.serialize();
                rep = $('#rep', form);
                rep.slideUp();
                $.ajax({
                    url: '{{ route('init_payment') }}',
                    type: 'POST',
                    data: data,
                    timeout: 30000,
                    success: function(res) {
                        console.log(res);
                        if (res.success == true) {
                            rep.html(res.message).removeClass();
                            rep.addClass('alert alert-success');
                            rep.slideDown();
                            btn.html(
                                '<i class="fa fa-spin fa-spinner"></i> En attente de validation ...'
                            );
                            btn.attr('disabled', true).removeClass('btn-dark').addClass(
                                'btn-danger');

                            clearInterval(interv);
                            REF = res.ref;
                            interv = setInterval(callback, 3000);
                            $('#btncancel').show();

                        } else {
                            var m = res.message;
                            rep.removeClass().addClass('alert alert-danger').html(m)
                                .slideDown();
                            btn.attr('disabled', false).find('i').removeClass().addClass(
                                iclass);
                        }
                    },
                    error: function(resp) {
                        var mess = resp.responseJSON?.message ??
                            "Une erreur s'est produite, merci de réessayer";
                        rep.removeClass().addClass('alert alert-danger').html(mess)
                            .slideDown();
                        btn.attr('disabled', false).find('i').removeClass().addClass(
                            iclass);
                    }

                });

            });

            function gettrans() {

                $.ajax({
                    url: '{{ route('transaction') }}',
                    success: function(data) {
                        var str = '';
                        $(data).each(function(i, e) {
                            str += `
                            <tr>
                            <td>${i+1}</td>
                            <td>${e.ref}</td>
                            <td>${e.amount} ${e.devise}</td>
                            <td>${e.telephone}</td>
                            <td>${e.date}</td>
                            <td>${e.paydata}</td>
                            </tr>
                        `;
                        });

                        $('[tdata]').find('tbody').html(str);
                    }
                })
            }

            gettrans();
        })
    </script>
</body>

</html>
