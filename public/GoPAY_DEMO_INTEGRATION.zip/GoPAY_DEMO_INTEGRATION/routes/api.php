<?php

use App\Http\Controllers\GoPAYController;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


// PROTECT THESE ROUTES WITH A MIDDLEWARE IS NECESSARY
Route::post('/payment/init', [GoPAYController::class, 'init_payment'])->name('init_payment');
Route::post('/payment/check', [GoPAYController::class, 'check_payment'])->name('check_payment');
Route::get('/transactions', function () {
    $trans = Transaction::orderBy('id', 'desc')->get();
    return ($trans);
})->name('transaction');
