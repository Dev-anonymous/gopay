<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gopay', function (Blueprint $table) {
            $table->id();
            $table->string('ref'); // for payment reference
            $table->string('issaved')->default(0); // check if transaction is already saved
            $table->boolean('isfailed')->default(0); // check id transaction was failed
            $table->string('paydata'); // extra data
            $table->dateTime('date')->useCurrent(); // date
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gopay');
    }
};
