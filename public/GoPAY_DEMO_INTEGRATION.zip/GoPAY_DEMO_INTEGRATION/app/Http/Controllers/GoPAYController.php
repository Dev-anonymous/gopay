<?php

namespace App\Http\Controllers;

use App\Models\Gopay;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GoPAYController extends Controller
{
    public function init_payment()
    {
        $validator = Validator::make(
            request()->all(),
            [
                'devise' => 'required|in:CDF,USD',
                'amount' => 'required|numeric',
                'telephone' => 'required'
            ]
        );

        if ($validator->fails()) {
            $m = implode(', ', $validator->errors()->all());
            return response([
                'success' => false,
                'message' => $m
            ]);
        }
        $tel = request()->telephone;
        $tel = "+243" . ((int) $tel);

        // THE PHONE NUMBER MUST BE LIKE : +24399.. or +24381...
        $ok = preg_match('/(\+24390|\+24399|\+24397|\+24398|\+24380|\+24381|\+24382|\+24383|\+24384|\+24385|\+24389)[0-9]{7}/', $tel);

        if (!$ok) {
            $m = "Le numéro $tel est invalide";
            return response([
                'success' => false,
                'message' => $m
            ]);
        }

        $devise = request()->devise;
        $amount = request()->amount;

        // MINIMUN AMOUNT IN CDF IS 500 CDF
        // MINIMUN AMOUNT IN USD IS 1 USD

        if ($devise == 'CDF' and $amount < 500) {
            return response([
                'success' => false,
                'message' => "Le montant minimum de paiement est de 500 CDF"
            ]);
        } else {
            if ($amount < 1) {
                return response([
                    'success' => false,
                    'message' => 'Le montant minimum de paiement est de 1 USD'
                ]);
            }
        }

        // CALL GOPAY API
        $r =   gopay_init_payment($amount, $devise, $tel);
        $ref = null;
        if ($r->success) {
            // create a pending transaction
            Gopay::create([
                'ref' => $r->data->ref,
                'issaved' => 0,
                'failled' => 0,
                'paydata' => json_encode([ // YOU CAN ADD HERE NECESSARY DATA RELATED TO THE PAYMENT SUCH AS THE USER ID, OR CART DATA WHEN YOUR ARE USING AN E-COMMERCE
                    'devise' => $devise,
                    'amount' => $amount,
                    'telephone' => $tel
                ]),
            ]);
            $ref = $r->data->ref;
        }

        return response([
            'success' => $r->success,
            'message' => $r->message,
            'ref' => $ref
        ]);
    }


    public function check_payment()
    {
        $ref = request()->ref;
        $ok =  false;
        $is_saved = 0;
        $trans = Gopay::where(['ref' => $ref])->lockForUpdate()->first();
        // YOU MUST TEMPORALY LOCK THE ROW TO AVOID THE TRANSACTION TO BE SAVED SEVERAL TIMES : LOL
        // IF YOUR ARE USING OTHER FRAMEWORK OR TECHNOLOGY, PLEASE REFER TO THE ACCORDING DATABASE MANUAL FOR LOCKING TABLE

        if ($ref) {
            $t = transaction_was_success($ref);
            // VERY IMPORTANT
            // IF TRUE : THE TRANSACTION WAS SUCCCED [OK]
            // IF FALSE : THE TRANSACTION WAS FAILED [NOT OK]
            // IF NULL : THE TRANSACTION IS IN PENDIND [NOT OK]
            // SO PLEASE MAKE SURE TO CHECK LIKE $t === TRUE, NOT $t == TRUE
            // OR $t === FALSE, NOT $t == FALSE

            if ($t === true) {
                $is_saved = @Gopay::where(['ref' => $ref])->first()->is_saved;
                if ($is_saved !== 1) {
                    $paydata = json_decode($trans->paydata); // THE ENCODED DATA WHEN TRANSACTION WAS INITIALISED
                    saveData($paydata, $trans);
                    $ok =  true;
                    $trans->update(['failled' => 0]);
                }
            } else {
                if ($t === false) {
                    $trans->update(['failled' => 1]);
                }
            }
        }

        if ($ok || $is_saved === 1) {
            // TRNSACTION WAS SUCCESS AND IT'S ALREADY SAVED
            return response([
                'success' => true,
                'message' => 'Votre paiement est effectué avec succès.'
            ]);
        } else {
            $m = "Aucune paiement trouvé.";
            return response([
                'success' => false,
                'message' => $m
            ]);
        }
    }
}
