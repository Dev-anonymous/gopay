<?php

use App\Models\Gopay;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

$xApiKey = "UVNlQ3BBdENjcHlQOFB5L1V3UGZYUT09";
"MFE2R0s0cEZMZVh2Rm8zb0tZNjNMdz09"; // REPLACE THIS WITH YOUR GOPAY PRODUCTION API KEY ==> https://gopay.gooomart.com/merchant-dash/integration

define('API_BASE', 'http://127.0.0.1:8000/api/v1');
// define('API_BASE', 'https://gopay.gooomart.com/api/v1');
define('API_HEADEARS',  [
    "Accept: application/json",
    "Content-Type: application/json",
    "x-api-key: $xApiKey"
]);


function gopay_init_payment($amount, $devise, $telephone)
{
    $_api_headers = API_HEADEARS;
    $telephone = (float) $telephone;
    $data = array(
        "telephone" => "+$telephone",
        "amount" => "$amount",
        "devise" => "$devise"
    );

    $data = json_encode($data);
    $gateway = API_BASE . "/payment/init";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $gateway);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $_api_headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
    $response = curl_exec($ch);
    $rep['success'] = false;
    if (curl_errno($ch)) {
        $rep['message'] = "Erreur, veuillez reessayer.";
    } else {
        $jsonRes = json_decode($response); // GOPAY API JSON RESPONSE
        // DD($jsonRes);  // UNCOMMENT TO SEE
        $rep['success'] = @$jsonRes->success;
        $rep['message'] = @$jsonRes->message;
        $rep['data'] = @$jsonRes->data;
    }
    curl_close($ch);
    return (object) $rep;
}

function completeTrans()
{
    // OPTIONAL :: CHECK ALL UNDONE PAYEMENTS IN BACKGROUN
    // YOU CAN CREATE A CRON JOB TO CALL THIS FUNCTION IN BACKGROUND TO COMPLETE ALL UNDONE PAYEMENTS
    $pendingPayments = Gopay::where(['issaved' => '0', 'failled' => '0'])->get();
    foreach ($pendingPayments as $e) {
        $paydata = json_decode($e->paydata);
        $ref = $e->ref;
        $t = transaction_status($ref);
        if ($t === true) {
            saveData($paydata, $ref);
        } else {
            if ($t === false) {
                $e->update(['failled' => 1]);
            }
        }
    }
}

function transaction_status($ref)
{
    $_api_headers = API_HEADEARS;

    $gateway = API_BASE . "/payment/check/" . $ref;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $gateway);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $_api_headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
    $response = curl_exec($ch);

    $status = null;
    if (!curl_errno($ch)) {
        curl_close($ch);
        $status = @json_decode($response)->transaction;
    }
    return $status;
}


function saveData($paydata, $trans)
{
    DB::transaction(function () use ($paydata, $trans) {
        Transaction::create([
            'ref' => $trans->ref, // IMPORTANT : TO AVOID DUPLICATED INSERTION
            'amount' => $paydata->amount,
            'devise' => $paydata->devise,
            'telephone' => $paydata->telephone,
            'paydata' => json_encode($paydata),
            'date' => now('Africa/Lubumbashi'),
        ]);
        $trans->update(['issaved' => 1]);
    });
}
